# Jon Mendizabal brand package

Made by Jig Studio from the brand item's revision 4 on 2026-11-14. AI-designed · check originality and trademarks before use.

## Contents

| Folder | What |
|---|---|
| `svg/` | The masters: every variant as SVG (Icon, Wordmark, Horizontal, Stacked, One colour, Reversed). Scale freely. |
| `pdf/` | The same variants as vector PDF, 100 mm on the longest side: for print shops. The reversed one sits on its dark background. |
| `png/` | Transparent PNGs: the icon at 16, 32, 48, 64, 128, 256, 512, 1024 px, the others 256, 512, 1024, 2048 px wide. The reversed SVG and PNGs are light on transparent: they look empty on white, put them on a dark background. |
| `favicon/` | `favicon.ico` (16, 32, 48 px, also as `favicon-<size>.png`), `favicon.svg`, `apple-touch-icon.png` (180 px), PWA icons (192, 512 and maskable 512 px), `site.webmanifest` and `head.html` with the lines for a page's head. |
| `social/` | `avatar-800.png` for profile pictures (cut to a circle) and `og-image.png` (1200 × 630) for link previews. |
| `tokens/` | `tokens.json` (W3C design tokens), `brand.css` (CSS variables), `tailwind.theme.css` (Tailwind v4) and `tailwind.config.js` (Tailwind v3). |
| `fonts/` | The logo's fonts (and the brand's text face, when it has its own) from Google Fonts as TTF, each family with its licence. |
| `icons/` | 6 icons in the logo's style: `svg/` in the brand colours, `mono/` in currentColor for code, `png/` at 24, 48, 96 px. |
| `patterns/` | 2 patterns: `-tile` is the seamless repeat unit (SVG, and PNG for CSS backgrounds), `-swatch` a sample. |
| `brand-book/` | The brand book as PDF: the logo's construction, clear space, minimum size, misuse, colours, type, icons, patterns and mockups. |
| `mockups/` | 4 mockup pictures of the logo in use. |
| `source/` | The logo's editable source for Jig Studio. |

## Colours

| Colour | HEX | RGB | HSL | CMYK (approximate) |
|---|---|---|---|---|
| primary | `#16324F` | 22, 50, 79 | hsl(211 56% 20%) | C 72 M 37 Y 0 K 69 |
| accent | `#FF5C35` | 255, 92, 53 | hsl(12 100% 60%) | C 0 M 64 Y 79 K 0 |
| ink | `#0E1116` | 14, 17, 22 | hsl(218 22% 7%) | C 36 M 23 Y 0 K 91 |
| paper | `#F3F2EE` | 243, 242, 238 | hsl(48 17% 94%) | C 0 M 0 Y 2 K 5 |

CMYK: Approximate: converted from sRGB by formula, without a printer's ICC profile. Ask the print shop for a proof; coated and uncoated paper differ.

Shade scales 50–950 of each colour (OKLCH) are in the tokens.

## Using the logo

- Minimum size: 120 px wide on screen, 28.3 mm in print.
- Clear space: keep 0.23 × the logo's height free on every side.
- Use the one-colour version where only one ink is available, the reversed one on dark backgrounds.
- Don't stretch, recolour, outline, rotate or add effects to the logo.

## Fonts

- **Barlow** 600: SIL Open Font License 1.1.

## Files

- `README.md`
- `brand-book/jon-mendizabal-brand-book.pdf`
- `favicon/apple-touch-icon.png`
- `favicon/favicon-16.png`
- `favicon/favicon-32.png`
- `favicon/favicon-48.png`
- `favicon/favicon.ico`
- `favicon/favicon.svg`
- `favicon/head.html`
- `favicon/icon-192.png`
- `favicon/icon-512.png`
- `favicon/icon-maskable-512.png`
- `favicon/site.webmanifest`
- `fonts/barlow/Barlow-600.ttf`
- `fonts/barlow/LICENSE.txt`
- `icons/mono/agent.svg`
- `icons/mono/cloud.svg`
- `icons/mono/data.svg`
- `icons/mono/review.svg`
- `icons/png/agent-24.png`
- `icons/png/agent-48.png`
- `icons/png/agent-96.png`
- `icons/png/cloud-24.png`
- `icons/png/cloud-48.png`
- `icons/png/cloud-96.png`
- `icons/png/code-24.png`
- `icons/png/code-48.png`
- `icons/png/code-96.png`
- `icons/png/data-24.png`
- `icons/png/data-48.png`
- `icons/png/data-96.png`
- `icons/png/layers-24.png`
- `icons/png/layers-48.png`
- `icons/png/layers-96.png`
- `icons/png/review-24.png`
- `icons/png/review-48.png`
- `icons/png/review-96.png`
- `icons/svg/agent.svg`
- `icons/svg/cloud.svg`
- `icons/svg/code.svg`
- `icons/svg/data.svg`
- `icons/svg/layers.svg`
- `icons/svg/review.svg`
- `mockups/app.png`
- `mockups/card.png`
- `mockups/sign.png`
- `mockups/social.png`
- `patterns/braces-swatch.svg`
- `patterns/braces-tile.png`
- `patterns/braces-tile.svg`
- `patterns/pour-swatch.svg`
- `patterns/pour-tile.png`
- `patterns/pour-tile.svg`
- `pdf/jon-mendizabal-horizontal.pdf`
- `pdf/jon-mendizabal-icon.pdf`
- `pdf/jon-mendizabal-one-colour.pdf`
- `pdf/jon-mendizabal-reversed.pdf`
- `pdf/jon-mendizabal-stacked.pdf`
- `pdf/jon-mendizabal-wordmark.pdf`
- `png/horizontal/jon-mendizabal-horizontal-1024w.png`
- `png/horizontal/jon-mendizabal-horizontal-2048w.png`
- `png/horizontal/jon-mendizabal-horizontal-256w.png`
- `png/horizontal/jon-mendizabal-horizontal-512w.png`
- `png/icon/jon-mendizabal-icon-1024.png`
- `png/icon/jon-mendizabal-icon-128.png`
- `png/icon/jon-mendizabal-icon-16.png`
- `png/icon/jon-mendizabal-icon-256.png`
- `png/icon/jon-mendizabal-icon-32.png`
- `png/icon/jon-mendizabal-icon-48.png`
- `png/icon/jon-mendizabal-icon-512.png`
- `png/icon/jon-mendizabal-icon-64.png`
- `png/one-colour/jon-mendizabal-one-colour-1024w.png`
- `png/one-colour/jon-mendizabal-one-colour-2048w.png`
- `png/one-colour/jon-mendizabal-one-colour-256w.png`
- `png/one-colour/jon-mendizabal-one-colour-512w.png`
- `png/reversed/jon-mendizabal-reversed-1024w.png`
- `png/reversed/jon-mendizabal-reversed-2048w.png`
- `png/reversed/jon-mendizabal-reversed-256w.png`
- `png/reversed/jon-mendizabal-reversed-512w.png`
- `png/stacked/jon-mendizabal-stacked-1024w.png`
- `png/stacked/jon-mendizabal-stacked-2048w.png`
- `png/stacked/jon-mendizabal-stacked-256w.png`
- `png/stacked/jon-mendizabal-stacked-512w.png`
- `png/wordmark/jon-mendizabal-wordmark-1024w.png`
- `png/wordmark/jon-mendizabal-wordmark-2048w.png`
- `png/wordmark/jon-mendizabal-wordmark-256w.png`
- `png/wordmark/jon-mendizabal-wordmark-512w.png`
- `social/avatar-800.png`
- `social/og-image.png`
- `source/jon-mendizabal.brand.json`
- `svg/jon-mendizabal-horizontal.svg`
- `svg/jon-mendizabal-icon.svg`
- `svg/jon-mendizabal-one-colour.svg`
- `svg/jon-mendizabal-reversed.svg`
- `svg/jon-mendizabal-stacked.svg`
- `svg/jon-mendizabal-wordmark.svg`
- `tokens/brand.css`
- `tokens/tailwind.config.js`
- `tokens/tailwind.theme.css`
- `tokens/tokens.json`
