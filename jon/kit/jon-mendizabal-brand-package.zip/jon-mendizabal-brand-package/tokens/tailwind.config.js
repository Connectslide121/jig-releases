// Jon Mendizabal brand tokens, from Jig Studio's brand package. CMYK in README.md is approximate.
// Tailwind v3: merge into tailwind.config.js.
module.exports = {
  "theme": {
    "extend": {
      "colors": {
        "primary": {
          "50": "#F1F6FC",
          "100": "#E0EDFC",
          "200": "#C5E0FD",
          "300": "#9ECAFA",
          "400": "#6FABEB",
          "500": "#5497DD",
          "600": "#4486CB",
          "700": "#3872AE",
          "800": "#316295",
          "900": "#2E5680",
          "950": "#16324F",
          "DEFAULT": "#16324F"
        },
        "accent": {
          "50": "#FFF2EF",
          "100": "#FFE1D9",
          "200": "#FFC7B9",
          "300": "#FF9F87",
          "400": "#FF5C35",
          "500": "#EE3B00",
          "600": "#D13300",
          "700": "#B02900",
          "800": "#942100",
          "900": "#801B00",
          "950": "#460A00",
          "DEFAULT": "#FF5C35"
        },
        "ink": {
          "50": "#F1F6FD",
          "100": "#E3E7EF",
          "200": "#D0D4DC",
          "300": "#B4B9C0",
          "400": "#92969D",
          "500": "#7B7F86",
          "600": "#676B72",
          "700": "#51555B",
          "800": "#3F4248",
          "900": "#30343A",
          "950": "#0E1116",
          "DEFAULT": "#0E1116"
        },
        "paper": {
          "50": "#F3F2EE",
          "100": "#E8E7E3",
          "200": "#D7D6D2",
          "300": "#BFBEBA",
          "400": "#9F9E9A",
          "500": "#8B8A86",
          "600": "#797875",
          "700": "#656460",
          "800": "#545350",
          "900": "#474643",
          "950": "#242421",
          "DEFAULT": "#F3F2EE"
        }
      },
      "fontFamily": {
        "barlow": [
          "Barlow"
        ],
        "heading": [
          "Barlow"
        ]
      }
    }
  }
};
